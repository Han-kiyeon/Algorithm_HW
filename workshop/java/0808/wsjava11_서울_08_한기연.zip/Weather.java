package com.wsjava11_서울_08_한기연;

public class Weather {
	private String hour; //시간
	private String temp; //온도
	private String wfKor; //날씨
	private String reh; //습도
	
	
	public Weather() {
		
	}


	public String getHour() {
		return hour;
	}


	public void setHour(String hour) {
		this.hour = hour;
	}


	public String getTemp() {
		return temp;
	}


	public void setTemp(String temp) {
		this.temp = temp;
	}


	public String getWfKor() {
		return wfKor;
	}


	public void setWfKor(String wfKor) {
		this.wfKor = wfKor;
	}


	public String getReh() {
		return reh;
	}


	public void setReh(String reh) {
		this.reh = reh;
	}


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Weather [시간 = ").append(hour)
		       .append(", 온도=").append(temp)
		       .append(", 날씨 = ").append(wfKor)
			   .append(", 습도 = ").append(reh).append("]");
		return builder.toString();
	}
	
	
	
	

}
