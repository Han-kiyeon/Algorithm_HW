package com.wsjava11_서울_08_한기연;

import java.util.List;

public interface IWeatherDAO {
	
	public List<Weather> getWeatherData();

	public void connectXML();

}
