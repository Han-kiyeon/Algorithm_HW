package com.wsjava11_서울_08_한기연;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class WeatherDAO implements IWeatherDAO {

	ArrayList<Weather> nlist;

	public WeatherDAO() {
		nlist = new ArrayList<>();
	}

	// 1.전달된 url에 접속해서 xml문서 받아오기
	// 2.xml문서 parsing
	// 3.원하는 element 찾아서 vo에 담기
	// 4.vo를 list에 담아서 리턴
	public List<Weather> getWeatherData() {
		connectXML();
		return nlist;
	}

	@Override
	public void connectXML() {
		try {
			String url = "http://www.kma.go.kr/wid/queryDFSRSS.jsp?zone=1168064000";
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(url); // Parsing >> DOM Tree생성.

			// title, date parsing
			NodeList list = doc.getElementsByTagName("data");

			if (nlist != null)
				nlist.clear();
			for (int i = 0; i < list.getLength(); i++) {
				Node item = list.item(i); // 기사 1건
				NodeList child = item.getChildNodes();// 기사 1건의 자식들.

				Weather n = new Weather();// VO 작성

				for (int j = 0; j < child.getLength(); j++) {
					Node one = child.item(j);
					String name = one.getNodeName();

					if (name.equals("hour"))
						n.setHour(one.getFirstChild().getNodeValue());
					else if (name.equals("temp"))
						n.setTemp(one.getFirstChild().getNodeValue());
					else if (name.equals("wfKor"))
						n.setWfKor(one.getFirstChild().getNodeValue());
					else if (name.equals("reh")) {
						n.setReh(one.getFirstChild().getNodeValue());
						System.out.println(n);
						nlist.add(n);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
