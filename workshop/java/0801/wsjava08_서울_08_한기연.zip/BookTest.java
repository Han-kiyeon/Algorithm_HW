package com.ssafy;

public class BookTest {

	public static void main(String[] args) {
		BookMgrlmpl bml = BookMgrlmpl.getInstance();

		System.out.println("\n-----------add()-----------");
		bml.add(new Novel("21424", "Java Basic", 15000, 10, "코믹"));
		bml.add(new Novel("21424", "JDBC Pro", 8000, 10, "교양"));
		bml.add(new Novel("55355", "Servlet/JSP", 19900, 10, "호러"));
		bml.add(new Novel("35332", "Android App", 35000, 10, "드라마"));
		bml.add(new Novel("35355", "OOAD 분석, 설계", 15000, 10, "스릴러"));

		bml.add(new Magazine("35535", "Java World", 14700, 15, 10));
		bml.add(new Magazine("33434", "Mobile World", 8000, 20, 03));
		bml.add(new Magazine("75342", "Next Web", 10000, 10, 10));
		bml.add(new Magazine("76543", "Architecture", 5000, 3, 12));
		bml.add(new Magazine("76534", "Data Modeling", 14000, 12, 11));
		bml.add(new Magazine("76544", "어차피.일할거라면", 14000, 12, 10));

		for (Book b : bml.list)
			System.out.println(b);

		System.out.println("\n-----------search()-----------");
		for (Book b : bml.search())
			System.out.println(b);

		System.out.println("\n-----------정상 상황 sell(\"35535\", 10)-----------");
		try {
			bml.sell("35535", 10);
		} catch (QuantityException e) {
			System.out.println(e);
		} catch (ISBNNotFoundException e) {
			System.out.println(e);
		}
		for (Book b : bml.search())
			System.out.println(b);

		System.out.println("\n-----------QuantityException 상황 sell(\"35535\", 10)-----------");
		try {
			bml.sell("35535", 10);
			for (Book b : bml.search())
				System.out.println(b);
		} catch (QuantityException e) {
			System.out.println(e);
		} catch (ISBNNotFoundException e) {
			System.out.println(e);
		}

		System.out.println("\n-----------ISBNNotFoundException 상황 sell(\"3553500\", 10)-----------");
		try {
			bml.sell("3553500", 10);
			for (Book b : bml.search())
				System.out.println(b);
		} catch (QuantityException e) {
			System.out.println(e);
		} catch (ISBNNotFoundException e) {
			System.out.println(e);
		}

		System.out.println("\n-----------정상 상황 buy(\"35535\", 10)-----------");
		try {
			bml.buy("35535", 10);
			for (Book b : bml.search())
				System.out.println(b);
		} catch (ISBNNotFoundException e) {
			System.out.println(e);
		}
		
		System.out.println("\n-----------ISBNNotFoundException 상황 buy(\"3553500\", 10)-----------");
		try {
			bml.buy("3553500", 10);
			for (Book b : bml.search())
				System.out.println(b);
		} catch (ISBNNotFoundException e) {
			System.out.println(e);
		}
		System.out.println("\n-----------getTotalAmount()-----------");

		System.out.println(bml.getTotalAmount());
		
		bml.close();

	}

}
