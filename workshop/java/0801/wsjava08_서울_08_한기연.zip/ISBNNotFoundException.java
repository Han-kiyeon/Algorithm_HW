package com.ssafy;

public class ISBNNotFoundException extends Exception{

	@Override
	public String toString() {
		
		return "ISBNNotFoundException 발생";
	}
	
	

}
