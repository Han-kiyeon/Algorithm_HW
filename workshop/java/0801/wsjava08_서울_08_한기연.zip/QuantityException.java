package com.ssafy;

public class QuantityException extends Exception {

	@Override
	public String toString() {
		return "QuantityException 발생";
	}

}
