package com.wsjava10_서울_08_한기연;

public class ISBNNotFoundException extends Exception{

	@Override
	public String toString() {
		
		return "ISBNNotFoundException 발생";
	}
	
	

}
