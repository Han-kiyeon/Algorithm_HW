package com.wsjava10_서울_08_한기연;

import java.io.*;
import java.net.Socket;
import java.util.*;

public class BookMgrlmpl implements IBookMgr {
	
	@Override
	public void send() {
		BookClient bc = new BookClient();//thread
		bc.start();
	}

	// 내부 클래스(Nested Class)
	class BookClient extends Thread {

		@Override
		public void run() {
			try {
				// 서버로 접속한 후 list를 보냄
				Socket s = new Socket("127.0.0.1", 6000);

				OutputStream out = s.getOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(out);

				oos.writeObject(list);

				oos.close();
				out.close();

				s.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}

	ArrayList<Book> list;

	private static BookMgrlmpl instance;

	private BookMgrlmpl() {
		list = new ArrayList<>();
		// 파일에서 ArrayList 읽어 옴
		open();
	}

	public static BookMgrlmpl getInstance() {
		if (instance == null)
			instance = new BookMgrlmpl();
		return instance;
	}

	@Override
	public void add(Book b) {
		for (Book book : list)
			if (book.equals(b)) {
				System.out.println("동일한 책입니다.");
				return;
			}
		list.add(b);
	}

	@Override
	public List<Book> search() {
		return list;
	}

	@Override
	public void sell(String isbn, int quantity) throws QuantityException, ISBNNotFoundException {
		for (Book b : list) {
			if (b.getIsbn().equals(isbn)) {
				if (b.getQuantity() > quantity)
					b.setQuantity(b.getQuantity() - quantity);
				else if (b.getQuantity() == quantity)
					list.remove(b);
				else
					throw new QuantityException();
				return;
			}
		}
		throw new ISBNNotFoundException();
	}

	@Override
	public void buy(String isbn, int quantity) throws ISBNNotFoundException {
		for (Book b : list) {
			if (b.getIsbn().equals(isbn)) {
				b.setQuantity(b.getQuantity() + quantity);
				return;
			}
		}
		throw new ISBNNotFoundException();
	}

	@Override
	public int getTotalAmount() {
		int tot = 0;
		for (int i = 0; i < list.size(); i++) {
			tot += list.get(i).getPrice() * list.get(i).getQuantity();
		}
		return tot;
	}

	@Override
	public void open() {
		try {
			FileInputStream fis = new FileInputStream("data.dat");
			ObjectInputStream ois = new ObjectInputStream(fis);

			Object obj = ois.readObject();

			if (obj != null) {
				list = (ArrayList<Book>) obj;
				System.out.println("file open");
			}

			ois.close();
			fis.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void close() {
		try {
			FileOutputStream fos = new FileOutputStream("data.dat");
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			oos.writeObject(list);

			oos.close();
			fos.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
