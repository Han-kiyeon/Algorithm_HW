package com.wsjava10_서울_08_한기연;

import java.io.Serializable;

public class Book implements Serializable{
	private String isbn; // key
	private String title;// 제목
	private int price; // 가격
	private int quantity; // 양
	
	
	public Book(String isbn, String title, int price, int quantity) {
		this.isbn = isbn;
		this.title = title;
		this.price = price;
		this.quantity = quantity;
	}


	public String getIsbn() {
		return isbn;
	}


	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(isbn).append("\t\t|")
		       .append(title).append("\t\t|")
		       .append(price).append("\t\t|")
		       .append(quantity).append("\t\t|");
		return builder.toString();
	}
	
	
	
	
	
	

}
