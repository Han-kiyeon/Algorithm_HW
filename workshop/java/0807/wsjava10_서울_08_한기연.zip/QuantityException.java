package com.wsjava10_서울_08_한기연;

public class QuantityException extends Exception {

	@Override
	public String toString() {
		return "QuantityException 발생";
	}

}
