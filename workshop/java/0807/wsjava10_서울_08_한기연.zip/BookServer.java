package com.wsjava10_서울_08_한기연;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class BookServer {
	public static void main(String[] args) throws Exception {
		ServerSocket server;
		Socket s; // 접속해 들어 올 클라이언트 소켓

		
		InputStream in;
		ObjectInputStream ois;

		server = new ServerSocket(5959); // 1.서버 소켓 생성

		while (true) {
			System.out.println("클라이언트를 기다리는 중....");
			// Block : 자신이 원하는 결과(클라이언트 접속)가 올때까지 대기상태.
			// 2.클라이언트 접속을 기다렸다 받음(Block이 되는 특징)
			s = server.accept();
			System.out.println("클라이언트 접속!");

			
			in = s.getInputStream();
			ois = new ObjectInputStream(in);
		
			Object result = ois.readObject(); // **************Block
			System.out.println(result);

			ois.close();
			in.close();

			s.close();
		}
	}
}
