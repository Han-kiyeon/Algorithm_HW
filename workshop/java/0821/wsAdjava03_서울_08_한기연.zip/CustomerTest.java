package com.tier3;

import java.util.*;

//client Program : DAO를 이용하는 객체
public class CustomerTest {
	public static Scanner sc = new Scanner(System.in);
	public static boolean flag = true;
	public static CustomerDAO dao = new CustomerDAO();

	public static void menu() {
		String num, name, address;
		ArrayList<Customer> list;
		System.out.println();
		System.out.println("---------MENU---------");
		System.out.println("1. 테이블 안의 모든 레코드 검색");
		System.out.println("2. num을 기준으로 레코드 검색");
		System.out.println("3. 새로운 레코드 추가");
		System.out.println("4. num을 기준으로 레코드 삭제");
		System.out.println("5. num을 기준으로 주소 수정");
		System.out.println("6. 주소를 기준으로 검색");
		System.out.println("7. 종료");
		System.out.println("----------------------");
		System.out.print("INPUT : ");

		switch (sc.nextInt()) {
		case 1:
			list = dao.selectAll();
			for (Customer i : list)
				System.out.println(i);
			break;
		case 2:
			System.out.print("검색 할 num값을 입력하시오 : ");
			num = sc.next();
			System.out.println(dao.selectOne(num));
			break;
		case 3:
			Customer c = new Customer();
			System.out.print("새로운 레코드의 num 값을 입력하시오.");
			c.setNum(sc.next());
			System.out.print("새로운 레코드의 name 값을 입력하시오.");
			c.setName(sc.next());
			System.out.print("새로운 레코드의 address 값을 입력하시오.");
			c.setAddress(sc.next());

			if (dao.insert(c) != -1)
				System.out.println("성공~!!");
			else
				System.out.println("실패ㅠㅠ");
			break;

		case 4:
			System.out.print("삭제 할 레코드의 num 값을 입력하시오.");
			if (dao.delete(sc.next()) != -1)
				System.out.println("성공~!!");
			else
				System.out.println("실패ㅠㅠ");
			break;

		case 5:
			System.out.print("수정 할 num값을 입력하시오 : ");
			num = sc.next();
			System.out.print("수정 할 address값을 입력하시오 : ");
			address = sc.next();
			if (dao.update(num, address) != -1)
				System.out.println("성공~!!");
			else
				System.out.println("실패ㅠㅠ");
			break;

		case 6:
			System.out.print("검색 할 address값을 입력하시오 : ");
			address = sc.next();
			list = dao.findByAddress(address);
			for (Customer i : list)
				System.out.println(i);
			break;

		case 7:
			System.out.println("종료~~~");
		default:
			flag = false;
			break;
		}
	}

	public static void main(String[] args) {
		while (flag)
			menu();
	}
}
