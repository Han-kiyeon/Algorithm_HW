package com.tier3;

//1.  VO작성 : customer 테이블 안의 에코드 한개의 값을 저장하기 위한 객체
public class Customer {
	// filed: 테이블 안의 컬럼과 동일하게 추출
	private String num;
	private String name;
	private String address;

	// constructor
	public Customer() {
	}


	public Customer(String num, String name, String address) {
		super();
		this.num = num;
		this.name = name;
		this.address = address;
	}



	// getter & setter
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}


	@Override
	public String toString() {
		return num + " | " + name + " --------- " + address;
	}

	//toString
	
}
