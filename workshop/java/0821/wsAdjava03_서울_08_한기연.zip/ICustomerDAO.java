package com.tier3;

import java.util.*;

//2. interface 작성 : DAO가 구현해야하는 메소드 목록
public interface ICustomerDAO {
	// 테이블 안의 모든 레코드 검색
	ArrayList<Customer> selectAll();

	// num을 기준으로 레코드 검색
	Customer selectOne(String num);

	// 새로운 레코드 추가
	int insert(Customer cus);

	// num을 기준으로 레코드 삭제
	int delete(String number);

	// num을 기준으로 주소 수정
	int update(String number, String address);

	// 주소를 기준으로 검색
	ArrayList<Customer> findByAddress(String address);
}
