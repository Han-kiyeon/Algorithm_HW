package com.ssafy5;

public class TV extends Product {
	private int inch;
	private String display;

	public TV(String model, String name, int price,
			int stock, int inch, String display) {
		super(model, name, price, stock);
		this.inch = inch;
		this.display = display;
	}
	
	 

	public int getInch() {
		return inch;
	}



	public void setInch(int inch) {
		this.inch = inch;
	}



	public String getDisplay() {
		return display;
	}



	public void setDisplay(String display) {
		this.display = display;
	}



	@Override
	public String toString() {
		return super.toString() + "\t|" + inch + "inch\t|" + display;
	}

}
