package com.ssafy5;

public class ProductTest {

	public static void main(String[] args) {
		ProductMgr pm = new ProductMgr();
		
		// 상품정보(TV와 Refrigerator)를 저장
		System.out.println("----------------가전제품 정보----------------");
		pm.add(new TV("12345", "삼성TV", 150000, 3, 30, "LCD"));
		pm.add(new TV("02345", "삼성TV", 100000, 3, 25, "LED"));
		pm.add(new TV("45687", "싸피TV", 189000, 5, 55, "OLED"));
		pm.add(new TV("66774", "LG TV", 390000, 1, 27, "LCD"));
		pm.add(new Refrigerator("66374", "삼성냉장고", 398000, 1, 300));
		pm.add(new Refrigerator("28379", "싸피냉장고", 475900, 2, 400));

		// 상품정보 전체를 검색하는 기능
		for (Product v : pm.total())
			System.out.println(v.toString());

		// 상품번호로 상품을 검색하는 기능
		System.out.println("---------------- find by Model Num ----------------");
		for (Product v : pm.searchByNum("12345"))
			System.out.println(v.toString());
		
		// 상품명으로 상품을 검색하는 기능(상품명 부분 검색 가능)
		System.out.println("---------------- find by Name ----------------");
		for (Product v : pm.searchByName("삼성"))
			System.out.println(v.toString());
		
		// TV정보만 검색하는 기능
		System.out.println("---------------- find by TV ----------------");
		for (Product v : pm.searchByTV())
			System.out.println(v.toString());
		
		// Refrigerator만 검색하는 기능
		System.out.println("---------------- find by Refrigerator ----------------");
		for (Product v : pm.searchByRefrigerator())
			System.out.println(v.toString());
		
		
		// 400L이상의 Refrigerator 검색
		System.out.println("---------------- searchByRefrigeratorUpperAmount ----------------");
		for (Product v : pm.searchByRefrigeratorUpperAmount(400))
			System.out.println(v.toString());

		// 50inch 이상의 TV검색
		System.out.println("---------------- serchByTVUpperInch ----------------");
		for (Product v : pm.serchByTVUpperInch(50))
			System.out.println(v.toString());
		
		// 상품번호와 가격을 입력받아 상품 가격을 변경할 수 있는 기능
		System.out.println("---------------- editPrice ----------------");
		pm.editPrice("66374", 500000);
		for (Product v : pm.total())
			System.out.println(v.toString());
		// 상품번호로 상품을 삭제하는 기능
		System.out.println("---------------- delete by model ----------------");
		pm.delete("66374");
		for (Product v : pm.total())
			System.out.println(v.toString());

		// 전체 재고 상품금액을 구하는기능
		System.out.println("---------------- sum ----------------");
		System.out.println(pm.sum());
		


		/*System.out.println("---------------- stock Price Type ----------------");
		System.out.println(pm.getPriceByType("TV"));

		System.out.println("---------------- stock Price class ----------------");
		System.out.println(pm.getPriceByType(new Refrigerator(null, null, 0, 0, 0)));

		System.out.println("---------------- TV inch Avg ----------------");
		System.out.println(pm.getTVInchAvg());

		System.out.println("---------------- Refrigerator Amm som ----------------");
		System.out.println(pm.getRefriAmoutSum());

		System.out.println("---------------- model under price ----------------");
		for (Product v : pm.getUnderPrice("삼성", 90000000))
			System.out.println(v.toString());*/

	}

}
