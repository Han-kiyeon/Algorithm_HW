package com.ssafy5;

import java.util.Arrays;

public class ProductMgr implements IProductMgr {
	private Product[] products = new Product[10];
	private int index;

	// 상품정보(TV와 Refrigerator)를 저장
	@Override
	public void add(Product product) {
		products[index++] = product;
	}

	// 상품정보 전체를 검색하는 기능
	@Override
	public Product[] total() {
		return Arrays.copyOf(products, index);
	}

	// 상품번호로 상품을 검색하는 기능
	@Override
	public Product[] searchByNum(String model) {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getModel().contains(model))
				cnt++;

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getModel().contains(model))
				tmp[cnt++] = products[i];
		return tmp;
	}

	// 상품명으로 상품을 검색하는 기능(상품명 부분 검색 가능)
	@Override
	public Product[] searchByName(String name) {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getName().contains(name))
				cnt++;

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getName().contains(name))
				tmp[cnt++] = products[i];
		return tmp;
	}

	// TV정보만 검색하는 기능
	@Override
	public Product[] searchByTV() {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("TV"))
				cnt++;

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("TV"))
				tmp[cnt++] = products[i];
		return tmp;
	}

	// Refrigerator만 검색하는 기능
	@Override
	public Product[] searchByRefrigerator() {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("Refrigerator"))
				cnt++;

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("Refrigerator"))
				tmp[cnt++] = products[i];
		return tmp;
	}

	// 400L이상의 Refrigerator 검색
	@Override
	public Product[] searchByRefrigeratorUpperAmount(int amount) {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("Refrigerator")) {
				Refrigerator r = (Refrigerator) products[i];
				if (r.getAmount() >= amount)
					cnt++;
			}

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("Refrigerator")) {
				Refrigerator r = (Refrigerator) products[i];
				if (r.getAmount() >= amount)
					tmp[cnt++] = products[i];
			}
		return tmp;
	}

	// 50inch 이상의 TV검색
	@Override
	public Product[] serchByTVUpperInch(int inch) {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("TV")) {
				TV t = (TV) products[i];
				if (t.getInch() >= inch)
					cnt++;
			}

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("TV")) {
				TV t = (TV) products[i];
				if (t.getInch() >= inch)
					tmp[cnt++] = products[i];
			}
		return tmp;
	}

	// 상품번호와 가격을 입력받아 상품 가격을 변경할 수 있는 기능
	@Override
	public void editPrice(String model, int price) {
		for (int i = 0; i < index; i++)
			if (products[i].getModel().contains(model)) 
				products[i].setPrice(price);		
	}

	// 상품번호로 상품을 삭제하는 기능
	@Override
	public void delete(String model) {
		for (int i = 0; i < index; i++)
			if (products[i].getModel().contains(model)) {
				products[i] = products[--index];
				products[index] = null;
				i--;
			}
	}

	// 전체 재고 상품금액을 구하는기능
	@Override
	public int sum() {
		int sum = 0;
		for (int i = 0; i < index; i++)
			sum += products[i].getPrice();
		return sum;
	}

	/*
	 * @Override public int getPriceByType(String type) { int stockPrice = 0; for
	 * (int i = 0; i < index; i++) if
	 * (products[i].getClass().getSimpleName().equals(type)) stockPrice +=
	 * products[i].getStock() * products[i].getPrice(); return stockPrice; }
	 * 
	 * @Override public int getPriceByType(Product product) { int stockPrice = 0;
	 * 
	 * if (product instanceof TV) { // 제품이 Tv for (int i = 0; i < index; i++) if
	 * (products[i] instanceof TV) stockPrice += products[i].getStock() *
	 * products[i].getPrice(); } else if (product instanceof Refrigerator) for (int
	 * i = 0; i < index; i++) if (products[i] instanceof Refrigerator) stockPrice +=
	 * products[i].getStock() * products[i].getPrice();
	 * 
	 * return stockPrice; }
	 * 
	 * @Override public double getTVInchAvg() { double avg = 0.0; int cnt = 0; for
	 * (int i = 0; i < index; i++) if (products[i] instanceof TV) { TV tmp = (TV)
	 * products[i]; avg += tmp.getInch(); cnt++; } return avg / cnt; }
	 * 
	 * @Override public int getRefriAmoutSum() { int sum = 0; for (int i = 0; i <
	 * index; i++) if (products[i] instanceof Refrigerator) { Refrigerator tmp =
	 * (Refrigerator) products[i]; sum += tmp.getAmount(); } return sum; }
	 * 
	 * @Override public Product[] getUnderPrice(String name, int price) { Product[]
	 * tmp; int cnt = 0; for (int i = 0; i < index; i++) if
	 * (products[i].getName().contains(name)) if (products[i].getPrice() < price)
	 * cnt++;
	 * 
	 * tmp = new Product[cnt]; cnt = 0;
	 * 
	 * for (int i = 0; i < index; i++) if (products[i].getName().contains(name)) if
	 * (products[i].getPrice() < price) tmp[cnt++] = products[i];
	 * 
	 * return tmp; }
	 */

}
