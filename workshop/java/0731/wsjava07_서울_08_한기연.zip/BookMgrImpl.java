package com.ssafy.seven;

import java.util.ArrayList;

public class BookMgrImpl implements IBookMgr {
	ArrayList<Book> list = new ArrayList<>();

	private static BookMgrImpl instance;	
	private BookMgrImpl() {}
	public static BookMgrImpl getInstance() {
		if(instance==null)instance=new BookMgrImpl();
		return instance;
	} 
	@Override
	public void add(Book book) {
		list.add(book);
	}
	@Override
	public ArrayList<Book> allBook() {
//		for(Book books:list)
//			System.out.println(books);
		return list;
	}

	@Override
	public Book findByIsbn(String isbn) {
		for (Book bn : list) {
			if (bn.getIsbn().equals(isbn))
				return bn;
		}
		return null;
	}

	@Override
	public ArrayList<Book> FindByTitle(String title) {
		ArrayList<Book> list2 = new ArrayList<>();
		for (Book bn : list) {
			if (bn.getTitle().contains(title))
				list2.add(bn);
		}	
		return list2;
	}

	@Override
	public ArrayList<Book> findNovel() {
		ArrayList<Book> list2 = new ArrayList<>();
		for (Book bn : list) {
			if (bn.getClass().getSimpleName().equals("Novel"))
				list2.add(bn);
		}	
		return list2;	}

	@Override
	public ArrayList<Book> findMagazine() {
		ArrayList<Book> list2 = new ArrayList<>();
		for (Book bn : list) {
			if (bn.getClass().getSimpleName().equals("Magazine"))
				list2.add(bn);
		}	
		return list2;	}

	@Override
	public ArrayList<Book> MagaOfyear(int year) {
		ArrayList<Magazine> list2 = new ArrayList<>();
		ArrayList<Book> list3 = new ArrayList<>();
		for (Book bn : list) {
			if (bn.getClass().getSimpleName().equals("Magazine"))
				list2.add((Magazine) bn);
		}
		for(Magazine bn:list2) {
			if(bn.getYear()==year)
				list3.add(bn);
		}
		return list3;	
		
	}
	


	@Override
	public ArrayList<Book> findByPublisher(String publisher) {
		ArrayList<Book> list2 = new ArrayList<>();
		for (Book bn : list) {
			if (bn.getPublisher().equals(publisher))
				list2.add(bn);
		}	
		return list2;	}

	@Override
	public ArrayList<Book> FindByPrice(int price) {
		ArrayList<Book> list2 = new ArrayList<>();
		for (Book bn : list) {
			if (bn.getPrice()<price)
				list2.add(bn);
		}	
		return list2;	}

	@Override
	public int Sum() {
		int sum=0;
		for (Book bn : list) {
			sum+=bn.getPrice();
		}
		return sum;
	}

	@Override
	public double Avg() {
		int cnt=0;
		for (Book bn : list) {
			cnt++;
		}
		return Sum()/cnt;
	}



	
}
