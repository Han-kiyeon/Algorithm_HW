package com.ssafy.seven;

import java.util.ArrayList;

//BookManager가 구현해야하는 11개의 메소드를 가지고 있는 인터페이스
public interface IBookMgr {

	//1.데이터 입력_ ArrayList에 책추가
	void add(Book book);
	
	//2. 전체 데이터  검색 기능 
	ArrayList<Book> allBook();

	//3.isbn으로 정보 검색 기능
	Book findByIsbn(String isbn);
	
	//4.Title로 정보 검색 기능(파라미터로 주어진 제목 포함 모든 정보)
	ArrayList<Book> FindByTitle(String title);
	
	//5. Novel만 검색
	ArrayList<Book> findNovel();
	//6.Magazine만 검색
	ArrayList<Book> findMagazine();
	//7.Magazine중 올해 잡지만 검색 하는 기능
	ArrayList<Book> MagaOfyear(int year);
	//8.출판사로 검색
	ArrayList<Book> findByPublisher(String publisher);

	//9.가격으로 검색 (파라미터로 주어진 가격보다 낮은 도서 정보 검색)
	ArrayList<Book> FindByPrice(int price);

	//10. 저장된 모든 도서의 금액 합계
	int Sum();
	//11.저장된 모든 도서 금액 평균
	double Avg();


}
