package com.ssafy.seven;

public class BookTest {

	public static void main(String[] args) {

		BookMgrImpl bm =BookMgrImpl.getInstance();
		
		bm.add(new Novel("21424", "Java Pro", "김하나", "Jane.kr", 15000, "Java 기본 문법", "교양"));
		bm.add(new Novel("35355", "분석 설계", "소나무", "Jane.kr", 30000, "sw 모델링", "추리"));
		bm.add(new Magazine("35535", "Java World", "편집부", "Java.com", 7000, "첫걸음", 2018, 2));
		bm.add(new Magazine("45612", "phthon", "SSAFY", "PHYTHON.COM", 5000, "두걸음", 2017, 9));
		bm.add(new Magazine("65452", "CLanguage", "S2_8", "C.com", 12000, "세걸음", 2013, 5));


		System.out.println("***********************도서목록**********************");
		for (Book i: bm.allBook()) {
			System.out.println(i);
			if(i==null)System.out.print("");}
		System.out.println();
		System.out.println("****************findByIsbn(\"21424\")*****************");

		System.out.println(bm.findByIsbn("21424"));
		System.out.println();
		System.out.println("**************FindByTitle(\"분석\")****************");

		for (Book i: bm.FindByTitle("분석")) {
			System.out.println(i);
			if(i==null)System.out.print("");
		}
		System.out.println();
		System.out.println("*****************findNovel()***************");

		for (Book i: bm.findNovel()) {
			System.out.println(i);
			if(i==null)System.out.print("");
		}
		System.out.println();
		System.out.println("******************findMagazine()*****************");

		for (Book i: bm.findMagazine()) {
			System.out.println(i);
			if(i==null)System.out.print("");
		}
		System.out.println();
		System.out.println("****************MagaOfyear(2017)*****************");

		for (Book i: bm.MagaOfyear(2017)) {
			System.out.println(i);
			if(i==null)System.out.print("");
		}
		System.out.println();
		System.out.println("************findByPublisher(\"Jane.kr\")****************");

		for (Book i: bm.findByPublisher("Jane.kr")) {
			System.out.println(i);
			if(i==null)System.out.print("");
		}
		System.out.println();
		System.out.println("****************FindByPrice(20000)******************");

		for (Book i: bm.FindByPrice(20000)) {
			System.out.println(i);
			if(i==null)System.out.print("");
		}
		System.out.println();
		System.out.println("****************Sum()*****************");

		System.out.println(bm.Sum());
		System.out.println();
		System.out.println("******************Avg()*******************");

		System.out.println(bm.Avg());

	}

}
