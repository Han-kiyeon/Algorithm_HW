package com.ssafy.seven;
//package com.ssafy.seven;
//
////BookManager: Magazine 과 Novel 을 관리하는 메소드들을 가지고있는 관리 클래스
//public class BookMgrImpl implements IBookMgr {
//	// field
//	Book[] list;// Magazine, Novel을 저장할 수 있는 배열 선언
//
//	int idx = 0;
//
//	public BookMgrImpl() {
//		list = new Book[5];
//	}
//
//	@Override
//	public void add(Book book) {
//		if (idx < list.length) {
//			list[idx] = book;
//			idx++;
//		}
//	}
//
//	@Override
//	public Book[] allBook() {
//		for (int i = 0; i < list.length; i++) {
//		if(list[i]==null)System.out.print("");
//		}
//		return list;	}
//
//	@Override
//	public Book findByIsbn(String isbn) {
//		for (int i = 0; i < list.length; i++) {
//			if (list[i].getIsbn() == isbn)
//				return list[i];
//		}
//		return null;
//	}
//
//
//	@Override
//	public Book[] FindByTitle(String title) {
//		int cnt = 0, idxT = 0;
//		for (int i = 0; i < list.length; i++) {
//			if (list[i].getTitle().contains(title))
//				cnt++;
//		}
//		if(cnt==0) {
//			System.out.println(title+"이 들어있는 책이 없습니다.");return null;}
//		Book[] bt = new Book[cnt];
//		for (int i = 0; i < list.length; i++) {
//			if (list[i].getTitle().contains(title))
//				bt[idxT++] = list[i];
//		}
//		return bt;
//	}
//
//
//	@Override
//	public Book[] findNovel() {
//		int cnt = 0, idxT = 0;
//		for (int i = 0; i < list.length; i++) {
//			if (list[i] instanceof Novel)
//				cnt++;
//		}if(cnt==0) {System.out.println("Novel이 없습니다");return null;}
//		Book[] bt = new Book[cnt];
//		for (int i = 0; i < list.length; i++) {
//			if (list[i] instanceof Novel)
//				bt[idxT++] = list[i];
//		}
//		return bt;
//	}
//
//
//	@Override
//	public Book[] findMagazine() {
//		int cnt = 0, idxT = 0;
//		for (int i = 0; i < list.length; i++) {
//			if (list[i] instanceof Magazine)
//				cnt++;
//		}if(cnt==0) {System.out.println("Magazine이 없습니다");return null;}
//		Book[] bt = new Book[cnt];
//		for (int i = 0; i < list.length; i++) {
//			if (list[i] instanceof Magazine)
//				bt[idxT++] = list[i];
//		}
//		return bt;
//	}
//
//
//	@Override
//	public Book[] MagaOfyear(int year) {
//		int cnt = 0, idxT = 0;Magazine m;
//		for (int i = 0; i < list.length; i++) {
//			if (list[i] instanceof Magazine) {
//				//m = (Magazine)list[i];
//				//if(m.getYear()==year)
//				cnt++;}
//		}if(cnt==0) {System.out.println("Magazine이 없습니다");return null;}
//		Book[] bt = new Book[cnt];
//		for (int i = 0; i < list.length; i++) {
//			if (list[i] instanceof Magazine) {
//				m = (Magazine)list[i];
//				if(m.getYear()==year)
//					bt[idxT++] = list[i];
//			}
//		}
//		return bt;	}
//
//	@Override
//	public Book[] findByPublisher(String publisher) {
//		int cnt = 0, idxT = 0;
//		for (int i = 0; i < list.length; i++) {
//			if (list[i].getPublisher()==publisher)
//				cnt++;
//		}
//		if(cnt==0) {System.out.println(publisher+" 출판사의 책이 없습니다.");return null;}
//		Book[] bt = new Book[cnt];
//		for (int i = 0; i < list.length; i++) {
//			if (list[i].getPublisher()==publisher)
//				bt[idxT++] = list[i];
//		}
//		return bt;
//	}
//
//	
//	@Override
//	public Book[] FindByPrice(int price) {
//		int cnt = 0, idxT = 0;
//		for (int i = 0; i < list.length; i++) {
//			if (list[i].getPrice()<price)
//				cnt++;
//		}
//		if(cnt==0) {System.out.println(price+"보다 낮은 가격의 책이 없습니다.");return null;}
//		Book[] bt = new Book[cnt];
//		for (int i = 0; i < list.length; i++) {
//			if (list[i].getPrice()<price)
//				bt[idxT++] = list[i];
//		}
//		return bt;
//	}
//
//
//	@Override
//	public int Sum() {
//		int sum=0;
//		for (int i = 0; i < list.length; i++) {
//			sum+=list[i].getPrice();
//		}	return sum;
//	}
//
//
//	@Override
//	public double Avg() {
//		return Sum()/5.0;
//	}
//
//}
