package com.hwjava11_서울_08_한기연;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class NewsDAOImpl implements INewsDAO {
	ArrayList<News> nlist;

	public NewsDAOImpl() {
		nlist = new ArrayList<>();
	}

	void connectNews(String url) {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder parser = factory.newDocumentBuilder();// Dom Parser

			Document doc = parser.parse(url); // parsing, dom tree 생성

			NodeList list = doc.getElementsByTagName("item");
			if (nlist != null)
				nlist.clear();

			for (int i = 0; i < list.getLength(); i++) {
				Node item = list.item(i);
				NodeList child = item.getChildNodes();

				News n = new News(); // vo 작성

				for (int j = 0; j < child.getLength(); j++) {

					nlist.add(search(j));
					Node one = child.item(j);
					String name = one.getNodeName();

					if (name.equals("title")) {
						n.setTitle(one.getFirstChild().getNodeValue());
						// System.out.print(one.getFirstChild().getNodeValue() + " : ");
					}
					if (name.equals("link")) {
						n.setLink(one.getFirstChild().getNodeValue());
						// System.out.print(one.getFirstChild().getNodeValue() + " : ");
					}
					if (name.equals("description")) {
						n.setDesc(one.getFirstChild().getNodeValue());
						// System.out.println(one.getFirstChild().getNodeValue().substring(0, 22));
						nlist.add(n);
						break;
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<News> getNewsData(String url) {
		connectNews(url);
		return nlist;
	}

	@Override
	public News search(int index) {
		return null;
	}

}
