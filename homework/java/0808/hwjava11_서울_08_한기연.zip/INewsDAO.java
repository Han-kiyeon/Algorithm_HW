package com.hwjava11_서울_08_한기연;

//interface
import java.util.List;

public interface INewsDAO {
	public List<News> getNewsData(String url);
	public News search(int index);
}
