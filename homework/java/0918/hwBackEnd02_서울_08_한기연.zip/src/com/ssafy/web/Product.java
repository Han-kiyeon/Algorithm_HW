package com.ssafy.web;


public class Product {
	String pname;
	int price;
	String description;

	public Product(String pname, int price, String description) {
		this.pname = pname;
		this.price = price;
		this.description = description;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
