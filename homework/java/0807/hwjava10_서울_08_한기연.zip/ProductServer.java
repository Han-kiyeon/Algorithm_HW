package com.hwjava10_서울_08_한기연.copy;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class ProductServer {
	public static void main(String[] args) throws Exception{
		ServerSocket ss;
		Socket s;
		InputStream in;
		ObjectInputStream ois;
		
		ss = new ServerSocket(7000);
		
		while(true) {
			System.out.println("---------------기다리는중");
			s = ss.accept();
			System.out.println("---------------연결완료");
			
			in = s.getInputStream();
			ois = new ObjectInputStream(in);
			
			ArrayList<Product> p = (ArrayList<Product>)ois.readObject();
			
			for(Product i:p) {
				System.out.println(i);
			}
			ois.close();
			in.close();
			s.close();
			
		}
	}
}
