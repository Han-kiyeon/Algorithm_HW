package com.hwjava10_서울_08_한기연.copy;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ProductMgrImpl implements IProductMgr {

	public void threadSave() {
		SaveThread st = new SaveThread();
		st.run();
	}
	
	@Override
	public void send() {
		ProductClient s = new ProductClient();
		s.start();
	}
	
	public class ProductClient extends Thread{

		public void run() {
			try {
				Socket s = new Socket("localhost", 7000);

				OutputStream os = s.getOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(os);

				oos.writeObject(list);

				oos.close();
				os.close();
				s.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public class SaveThread extends Thread{
		public void run() {
			try {
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
				oos.writeObject(list);
				
				oos.close();
			}catch(IOException e) {
				System.out.println(e);
			}
		
			System.out.println("저장");
		}
	}

	File file = new File("product.dat");

	private static ProductMgrImpl instance;

	private ArrayList<Product> list = new ArrayList<Product>();

	private ProductMgrImpl() {

	}

	public static ProductMgrImpl getInstance() {
		if (instance == null)
			return instance = new ProductMgrImpl();
		return instance;
	}

	@Override
	public void add(Product p) throws DuplicateException {
		for (Product ii : list) {
			if (ii.getIspn().equals(p.getIspn()))

				throw new DuplicateException();
		}
		list.add(p);
	}

	@Override
	public ArrayList<Product> allProduct() {
		return list;
	}

	@Override
	public Product findByIspn(String Ispn) throws CodeNotFoundException {
		for (int k = 0; k < list.size(); k++) {
			if (list.get(k).getIspn().equals(Ispn))
				return list.get(k);
		}
		throw new CodeNotFoundException();
	}

	@Override
	public ArrayList<Product> findByName(String title) {
		ArrayList<Product> t = new ArrayList<>();
		for (int k = 0; k < list.size(); k++) {
			if (list.get(k).getName().contains(title)) {
				t.add(list.get(k));
			}
		}
		return t;
	}

	@Override
	public ArrayList<Product> findTV() {
		ArrayList<Product> n = new ArrayList<>();
		int nCount = 0;
		for (int k = 0; k < list.size(); k++) {
			if (list.get(k) instanceof TV) {
				n.add(list.get(k));
			}
		}
		return n;
	}

	@Override
	public ArrayList<Product> findRefrigerator() {
		ArrayList<Product> n = new ArrayList<>();
		for (int k = 0; k < list.size(); k++) {
			if (list.get(k) instanceof Refrigerator) {
				n.add(list.get(k));
			}
		}
		return n;
	}

	@Override
	public void remove(String Ispn) {
		for (int k = 0; k < list.size(); k++) {
			if (list.get(k).getIspn().equals(Ispn)) {
				list.remove(k);
				return;
			}
		}
	}

	@Override
	public int sum() {
		int sum = 0;
		for (int k = 0; k < list.size(); k++) {
			if (list.get(k) != null)
				sum += list.get(k).getPrice() * list.get(k).getQuantity();
		}
		return sum;
	}

	@Override
	public ArrayList<Product> findOver400Refrigerator() throws ProductNotFoundException {
		ArrayList<Product> n = new ArrayList<>();
		for (int k = 0; k < list.size(); k++) {
			if (list.get(k) instanceof Refrigerator) {
				Refrigerator rf = (Refrigerator) list.get(k);
				if (rf.getVolume() >= 400)
					n.add(list.get(k));
			}
		}
		if (n == null)
			throw new ProductNotFoundException();
		return n;
	}

	@Override
	public ArrayList<Product> findOver50inch() throws ProductNotFoundException {
		ArrayList<Product> n = new ArrayList<>();
		for (int k = 0; k < list.size(); k++) {
			if (list.get(k) instanceof TV) {
				TV tv = (TV) list.get(k);
				if (tv.getInch() >= 50)
					n.add(list.get(k));
			}
		}
		if (n == null)
			throw new ProductNotFoundException();
		return n;
	}

	@Override
	public void modifyPrice(String num, int price) {
		for (int k = 0; k < list.size(); k++) {
			if (list.get(k).getIspn().equals(num))
				list.get(k).setPrice(price);
		}

	}

	@Override
	public void open() {

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
			Object obj = ois.readObject();
			if (obj != null)
				list = (ArrayList) obj;

			ois.close();
		} catch (ClassNotFoundException | IOException e) {
			System.out.println(e);
		}
	}

	@Override
	public void close() {
		/*
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
			oos.writeObject(list);
			
			oos.close();
		}catch(IOException e) {
			System.out.println(e);
		}
	
		System.out.println("저장");
		*/
	}
	

}
