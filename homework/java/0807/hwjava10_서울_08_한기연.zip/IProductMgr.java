package com.hwjava10_서울_08_한기연.copy;

import java.util.ArrayList;


class DuplicateException extends Exception{

	@Override
	public String toString() {
		return "DuplicateException 발생";
	}
	
}

class CodeNotFoundException extends Exception{

	@Override
	public String toString() {
		return "CodeNotFoundException 발생";
	}
	
}

class ProductNotFoundException extends Exception{

	@Override
	public String toString() {
		return "ProductNotFoundException 발생";
	}
	
}



//BookManager가 구현해야 되는 11개의 메소드를 가지고 있는 인터페이스
public interface IProductMgr {
	
	
	//1. 데이터 입력 
	void add(Product p) throws DuplicateException;
	
	//2. 전체 데이터 검색
	ArrayList<Product> allProduct();
	
	//3. 상품번호로 검색
	Product findByIspn(String Ispn) throws CodeNotFoundException;
	
	//4. 상품명으로 검색(부분검색가능)
	ArrayList<Product> findByName(String title);
	
	//5. TV정보만 검색
	ArrayList<Product> findTV();
	
	//6. 냉장고로 검색
	ArrayList<Product> findRefrigerator();
	
	ArrayList<Product> findOver400Refrigerator() throws ProductNotFoundException;
	
	ArrayList<Product> findOver50inch() throws ProductNotFoundException;
	
	void modifyPrice(String num, int price);
	
	void remove(String Ispn);

	int sum();
	
	void open();
	
	void close();
	
	void send();
	
	
	
}
