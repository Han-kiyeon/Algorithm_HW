package com.hwjava10_서울_08_한기연.copy;

class Refrigerator extends Product{
	int volume;
	
	public Refrigerator(String isbn, String name, int price, int quantity, int volume) {
		super(isbn, name, price, quantity);
		this.volume = volume;
	}
	
	public String toString() {
		return super.toString()+"\t|용량 : "+this.volume;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}
}