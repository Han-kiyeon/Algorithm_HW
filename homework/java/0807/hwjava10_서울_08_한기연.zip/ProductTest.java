package com.hwjava10_서울_08_한기연.copy;

import java.util.ArrayList;
import java.util.Scanner;

public class ProductTest{
	public static void main(String[] args) {
		
		ProductMgrImpl pm = ProductMgrImpl.getInstance();

		Scanner sc = new Scanner(System.in);
		
		ArrayList<Product> ap;
		int c;
		
		try {

			pm.open();
			
			do {	
				System.out.println("****** 메뉴 ******");
				System.out.println("1. 상품정보를 저장");
				System.out.println("2. 상품정보 전체를 검색하는 기능");
				System.out.println("3. 상품번호로 상품을 검색하는 기능");
				System.out.println("4. 상품명으로 상품을 검색하는 기능(부분검색가능)");
				System.out.println("5. TV정보만 검색");
				System.out.println("6. Refrigerator만 검색");
				System.out.println("7. 400L 이상의 Refrigerator 검색");
				System.out.println("8. 50inch 이상의 TV검색");
				System.out.println("9. 상품번호와 가격을 입력 받아 상품 가격을 변경할 수 있는 기능");
				System.out.println("10. 상품번호로 상품을 삭제하는 기능");
				System.out.println("11. 전체 재고 상품 금액을 구하는 기능");
				System.out.println("0. 저장");
				
				c = sc.nextInt();
				switch(c) {
				case 1:
					int ch;
					System.out.println("TV : 1 | Refrigerator : 2");
					ch =sc.nextInt();
					if(ch == 1) {
						System.out.println("상품번호 | 상품이름 | 상품가격 | 재고 | 인치 | 타입");
						
						String num=sc.next();
						String name=sc.next();
						int price=sc.nextInt();
						int q=sc.nextInt();
						int inch=sc.nextInt();
						String type=sc.next();
						pm.add(new TV(num,name,price,q,inch,type));
					}
					else {
						System.out.println("상품번호 | 상품이름 | 상품가격 | 재고 | 용량");
						String num=sc.next();
						String name=sc.next();
						int price=sc.nextInt();
						int q=sc.nextInt();
						int vol=sc.nextInt();
						pm.add(new Refrigerator(num,name,price,q,vol));
					}
					break;
				case 2:
					ap = pm.allProduct();
					for(Product p : ap) {
						System.out.println(p);
					}
					break;
				case 3:
					System.out.println("상품번호 입력");
					String num = sc.next();
					Product p = pm.findByIspn(num);
					System.out.println(p);
					break;
				case 4:
					String name=sc.next();
					ap = pm.findByName(name);
					for(Product a : ap) {
						System.out.println(a);
					}
					break;
				case 5:
					ap = pm.findTV();
					for(Product a : ap) {
						System.out.println(a);
					}
					break;
				case 6:
					ap = pm.findRefrigerator();
					for(Product a : ap) {
						System.out.println(a);
					}
					break;
				case 7:
					ap = pm.findOver400Refrigerator();
					for(Product a : ap) {
						System.out.println(a);
					}
					break;
				case 8:
					ap = pm.findOver50inch();
					for(Product a : ap) {
						System.out.println(a);
					}
					break;
				case 9:
					System.out.println("수정할 상품번호와 가격을 입력해주세요");
					name = sc.next();
					int price = sc.nextInt();
					pm.modifyPrice(name, price);
					break;
				case 10:
					System.out.println("삭제할 상품 번호를 입력해주세요");
					String rm = sc.next();
					pm.remove(rm);
					break;
				case 11:
					System.out.println("전체 재고 가격 : "+pm.sum());
					break;
				case 0:
					c=0;
					break;
				
				}
				
			}while(c != 0);
			
			pm.send();
			pm.threadSave();
		}catch(DuplicateException | CodeNotFoundException | ProductNotFoundException e) {
			System.out.println(e);
		}

		
		
		
		
		
		
		
		
	}
}
