package com.hwjava10_서울_08_한기연.copy;
class TV extends Product{
	int inch;
	String displayType;
	
	public TV(String isbn, String name, int price, int quantity, int inch, String displayType) {
		super(isbn, name, price, quantity);
		this.inch = inch;
		this.displayType = displayType;
	}
	
	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	public String getDisplayType() {
		return displayType;
	}

	public void setDisplayType(String displayType) {
		this.displayType = displayType;
	}

	public String toString() {
		return super.toString()+"\t|인치 : "+this.inch+"\t|타입 : "+this.displayType;
	}
	
}