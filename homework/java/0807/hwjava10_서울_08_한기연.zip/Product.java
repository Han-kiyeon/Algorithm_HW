package com.hwjava10_서울_08_한기연.copy;

import java.io.Serializable;

public class Product implements Serializable{
	String ispn;
	String name;
	int price;
	int Quantity;
	
	
	public Product(String isbn, String name, int price, int quantity) {
		this.ispn = isbn;
		this.name = name;
		this.price = price;
		this.Quantity = quantity;
	}

	public String getIspn() {
		return ispn;
	}


	public void setIspn(String ispn) {
		this.ispn = ispn;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public int getQuantity() {
		return Quantity;
	}


	public void setQuantity(int quantity) {
		Quantity = quantity;
	}


	@Override
	public String toString() {
		return "고유번호 : " + ispn + "\t|상품이름 : " + name + "\t|가격 : " + price + "\t|재고 : " + Quantity;
	}

}
