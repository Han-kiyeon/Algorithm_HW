package com.ssafy3;

public class ProductTest {

	public static void main(String[] args) {
		ProductMgr pm = new ProductMgr();
		System.out.println("----------------가전제품 정보----------------");
		pm.add(new TV("12345", "삼성TV", 150000, 3, 30, "LCD"));
		pm.add(new TV("02345", "삼성TV", 100000, 3, 25, "LED"));
		pm.add(new TV("45687", "싸피TV", 189000, 5, 55, "OLED"));
		pm.add(new TV("66374", "LG TV", 390000, 1, 27, "LCD"));
		pm.add(new Refrigerator("66374", "삼성냉장고", 398000, 1, 300));
		pm.add(new Refrigerator("28379", "싸피냉장고", 475900, 2, 400));

		for (Product v : pm.total())
			System.out.println(v.toString());

		System.out.println("---------------- find by Model Num ----------------");
		for (Product v : pm.searchByNum("12345"))
			System.out.println(v.toString());

		System.out.println("---------------- find by Name ----------------");
		for (Product v : pm.searchByName("삼성"))
			System.out.println(v.toString());

		System.out.println("---------------- find by TV ----------------");
		for (Product v : pm.searchByTV())
			System.out.println(v.toString());

		System.out.println("---------------- find by Refrigerator ----------------");
		for (Product v : pm.searchByRefrigerator())
			System.out.println(v.toString());

		System.out.println("---------------- del by price ----------------");
		pm.del("66374");
		for (Product v : pm.total())
			System.out.println(v.toString());

		System.out.println("---------------- sum ----------------");
		System.out.println(pm.sum());

		System.out.println("---------------- stock Price Type ----------------");
		System.out.println(pm.getPriceByType("TV"));

		System.out.println("---------------- stock Price class ----------------");
		System.out.println(pm.getPriceByType(new Refrigerator(null, null, 0, 0, 0)));

		System.out.println("---------------- TV inch Avg ----------------");
		System.out.println(pm.getTVInchAvg());

		System.out.println("---------------- Refrigerator Amm som ----------------");
		System.out.println(pm.getRefriAmmoutSum());

		System.out.println("---------------- model under price ----------------");
		for (Product v : pm.getUnderPrice("삼성", 90000000))
			System.out.println(v.toString());

	}

}
