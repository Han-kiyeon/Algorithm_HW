package com.ssafy3;

import java.util.Arrays;

public class ProductMgr implements IProductMgr {
	private Product[] products = new Product[10];
	private int index;

	@Override
	public void add(Product product) {
		products[index++] = product;
	}

	@Override
	public Product[] total() {
		return Arrays.copyOf(products, index);
	}

	@Override
	public Product[] searchByNum(String model) {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getModel().contains(model))
				cnt++;

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getModel().contains(model))
				tmp[cnt++] = products[i];
		return tmp;
	}

	@Override
	public Product[] searchByName(String name) {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getName().contains(name))
				cnt++;

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getName().contains(name))
				tmp[cnt++] = products[i];
		return tmp;
	}

	@Override
	public Product[] searchByTV() {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("TV"))
				cnt++;

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("TV"))
				tmp[cnt++] = products[i];
		return tmp;
	}

	@Override
	public Product[] searchByRefrigerator() {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("Refrigerator"))
				cnt++;

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("Refrigerator"))
				tmp[cnt++] = products[i];
		return tmp;
	}

	@Override
	public void del(String model) {
		for (int i = 0; i < index; i++)
			if (products[i].getModel().contains(model)) {
				products[i] = products[--index];
				products[index] = null;
				i--;
			}
	}

	@Override
	public int sum() {
		int sum = 0;
		for (int i = 0; i < index; i++)
			sum += products[i].getPrice();
		return sum;
	}

	@Override
	public int getPriceByType(String type) {
		int stockPrice = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals(type))
				stockPrice += products[i].getStock() * products[i].getPrice();
		return stockPrice;
	}

	@Override
	public int getPriceByType(Product product) {
		int stockPrice = 0;

		if (product instanceof TV) { // 제품이 Tv
			for (int i = 0; i < index; i++)
				if (products[i] instanceof TV)
					stockPrice += products[i].getStock() * products[i].getPrice();
		} else if (product instanceof Refrigerator)
			for (int i = 0; i < index; i++)
				if (products[i] instanceof Refrigerator)
					stockPrice += products[i].getStock() * products[i].getPrice();

		return stockPrice;
	}

	@Override
	public double getTVInchAvg() {
		double avg = 0.0;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i] instanceof TV) {
				TV tmp = (TV) products[i];
				avg += tmp.getInch();
				cnt++;
			}
		return avg / cnt;
	}

	@Override
	public int getRefriAmmoutSum() {
		int sum = 0;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i] instanceof Refrigerator) {
				Refrigerator tmp = (Refrigerator) products[i];
				sum += tmp.getAmount();
			}
		return sum;
	}

	@Override
	public Product[] getUnderPrice(String name, int price) {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getName().contains(name))
				if (products[i].getPrice() < price)
					cnt++;

		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getName().contains(name))
				if (products[i].getPrice() < price)
					tmp[cnt++] = products[i];

		return tmp;
	}
}
