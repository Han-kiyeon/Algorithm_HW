package com.d3;

import java.io.*;
import java.util.*;

public class Solution_D3_1234_비밀번호_한기연 {
	private static LinkedList<Integer> data;

	public static void main(String[] args) throws Exception {
		System.setIn(new FileInputStream("res/1234_D3_비밀번호.txt"));

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		StringTokenizer st;
		int T = 10;

		for (int tc = 1; tc <= T; tc++) {
			st = new StringTokenizer(br.readLine());
			int N = Integer.parseInt(st.nextToken());
			data = new LinkedList<>();
			String str = st.nextToken();
			for (int i = 0; i < N; i++)
				data.add(str.charAt(i) - '0');
			//System.out.println(data);

			while (true) {
				boolean flag = true;
				for (int i = 0; i < data.size() - 1; i++) {
					if (data.get(i) == data.get(i + 1)) {
						data.remove(i);
						data.remove(i);
						i--;
						flag = false;
					}
				}
				if (flag)
					break;
			}

			bw.write("#"+tc+" ");
			for(int x : data)
				bw.write(""+x);
			bw.write("\n");
		}

		br.close();
		bw.close();
	}
}
