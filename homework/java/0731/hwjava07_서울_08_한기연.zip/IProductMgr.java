package com.ssafy6;

import java.util.ArrayList;

public interface IProductMgr {
	// 상품정보(TV와 Refrigerator)를 저장
	void add(Product product);

	// 상품정보 전체를 검색하는 기능
	ArrayList<Product> total();

	// 상품번호로 상품을 검색하는 기능
	ArrayList<Product> searchByNum(String model);

	// 상품명으로 상품을 검색하는 기능(상품명 부분 검색 가능)
	ArrayList<Product> searchByName(String name);

	// TV정보만 검색하는 기능
	ArrayList<Product> searchByTV();

	// Refrigerator만 검색하는 기능
	ArrayList<Product> searchByRefrigerator();

	// 400L이상의 Refrigerator 검색
	ArrayList<Product> searchByRefrigeratorUpperAmount(int amount);
	
	// 50inch 이상의 TV검색
	ArrayList<Product> serchByTVUpperInch(int inch);
	
	// 상품번호와 가격을 입력받아 상품 가격을 변경할 수 있는 기능
	void editPrice(String model, int price);

	// 상품번호로 상품을 삭제하는 기능
	void delete(String model);

	// 전체 재고 상품금액을 구하는기능
	int sum();

}
