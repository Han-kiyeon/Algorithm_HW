package com.ssafy6;

public class Product {
	private String model; // 제품번호
	private String name;
	private int price;
	private int stock;

	public Product(String model, String name, int price, int stock) {
		this.model = model;
		this.name = name;
		this.price = price;
		this.stock = stock;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String toString() {
		return model + "\t|" + name + "  \t|" + price + "\t|" + stock;
	}
}
