package com.ssafy6;

import java.util.ArrayList;


public class ProductMgr implements IProductMgr {

	ArrayList<Product> products;
	
	
	private static ProductMgr instance;

	private ProductMgr() {
		products = new ArrayList<>();
	}
	
	public static ProductMgr getInstance() {
		if(instance==null)
			instance = new ProductMgr();
		
		return instance;
	}

	// 상품정보(TV와 Refrigerator)를 저장
	@Override
	public void add(Product product) {
		products.add(product);
	}

	// 상품정보 전체를 검색하는 기능
	@Override
	public ArrayList<Product> total() {
		return products;
	}

	// 상품번호로 상품을 검색하는 기능
	@Override
	public ArrayList<Product> searchByNum(String model) {
		ArrayList<Product> tmp = new ArrayList<>();
		for (int i = 0; i < products.size(); i++)
			if (products.get(i).getModel().contains(model))
				tmp.add(products.get(i));
		return tmp;
	}

	// 상품명으로 상품을 검색하는 기능(상품명 부분 검색 가능)
	@Override
	public ArrayList<Product> searchByName(String name) {
		ArrayList<Product> tmp = new ArrayList<>();
		for (int i = 0; i < products.size(); i++)
			if (products.get(i).getName().contains(name))
				tmp.add(products.get(i));
		return tmp;
	}

	// TV정보만 검색하는 기능
	@Override
	public ArrayList<Product> searchByTV() {
		ArrayList<Product> tmp = new ArrayList<>();
		for (int i = 0; i < products.size(); i++)
			if (products.get(i).getClass().getSimpleName().equals("TV"))
				tmp.add(products.get(i));
		return tmp;
	}

	// Refrigerator만 검색하는 기능
	@Override
	public ArrayList<Product> searchByRefrigerator() {
		ArrayList<Product> tmp = new ArrayList<>();
		for (int i = 0; i < products.size(); i++)
			if (products.get(i).getClass().getSimpleName().equals("Refrigerator"))
				tmp.add(products.get(i));
		return tmp;
	}

	// 400L이상의 Refrigerator 검색
	@Override
	public ArrayList<Product> searchByRefrigeratorUpperAmount(int amount) {
		ArrayList<Product> tmp = new ArrayList<>();
		for (int i = 0; i < products.size(); i++)
			if (products.get(i).getClass().getSimpleName().equals("Refrigerator")) {
				Refrigerator r = (Refrigerator) products.get(i);
				if (r.getAmount() >= amount)
					tmp.add(products.get(i));
			}
		return tmp;
	}

	// 50inch 이상의 TV검색
	@Override
	public ArrayList<Product> serchByTVUpperInch(int inch) {
		ArrayList<Product> tmp = new ArrayList<>();
		for (int i = 0; i < products.size(); i++)
			if (products.get(i).getClass().getSimpleName().equals("TV")) {
				TV t = (TV) products.get(i);
				if (t.getInch() >= inch)

					tmp.add(products.get(i));
			}
		return tmp;
	}

	// 상품번호와 가격을 입력받아 상품 가격을 변경할 수 있는 기능
	@Override
	public void editPrice(String model, int price) {
		for (int i = 0; i < products.size(); i++)
			if (products.get(i).getModel().contains(model))
				products.get(i).setPrice(price);
	}

	// 상품번호로 상품을 삭제하는 기능
	@Override
	public void delete(String model) {
		for (int i = 0; i < products.size(); i++)
			if (products.get(i).getModel().contains(model))
				products.remove(products.get(i));
	}

	// 전체 재고 상품금액을 구하는기능
	@Override
	public int sum() {
		int sum = 0;
		for (int i = 0; i < products.size(); i++)
			sum += products.get(i).getPrice();
		return sum;
	}

}
