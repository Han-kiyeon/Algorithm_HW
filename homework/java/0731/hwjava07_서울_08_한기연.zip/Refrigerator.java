package com.ssafy6;

public class Refrigerator extends Product {
	private int amount;

	public Refrigerator(String model, String name, int price, int stock, int amount) {
		super(model, name, price, stock);
		this.amount = amount;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return super.toString() + "\t|" + amount + "l";

	}
}
