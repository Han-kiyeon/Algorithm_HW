package com.ssafy;

public class TV {
	String num;
	String name;
	int price;
	int amount;
	int inch;
	String type;
	
	public TV(String num, String name, int price, int amount, int inch, String type) {
		this.num = num;
		this.name = name;
		this.price = price;
		this.amount = amount;
		this.inch = inch;
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "TV [num=" + num + ", name=" + name + ", price=" + price + ", amount=" + amount + ", inch=" + inch
				+ ", type=" + type + "]";
	}
	

}
