package com.ssafy;

public class Refrigerator {
	String num;
	String name;
	int price;
	int amount;
	int volume;
	public Refrigerator(String num, String name, int price, int amount, int volume) {
		super();
		this.num = num;
		this.name = name;
		this.price = price;
		this.amount = amount;
		this.volume = volume;
	}
	
	@Override
	public String toString() {
		return "Refrigerator [num=" + num + ", name=" + name + ", price=" + price + ", amount=" + amount + ", volume="
				+ volume + "]";
	}
	


	

}
