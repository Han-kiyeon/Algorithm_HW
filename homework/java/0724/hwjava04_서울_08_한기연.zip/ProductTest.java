package com.ssafy;

public class ProductTest {

	public static void main(String[] args) {
		TV t1 = new TV("35635", "SamsungTv", 300000, 1, 55, "OLED");
		Refrigerator r1 = new Refrigerator("35635", "Dimche", 350000, 1,500);

		System.out.println("********************************가전 목록 ********************************");
		System.out.println(t1.toString());
		System.out.println(r1.toString());

	}

}
