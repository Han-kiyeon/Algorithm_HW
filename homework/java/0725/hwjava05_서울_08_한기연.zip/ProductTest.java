package com.ssafy2;

public class ProductTest {


	public static void main(String[] args) {
		ProductMgr pm = new ProductMgr();
		System.out.println("----------------가전제품 정보----------------");
		pm.add(new TV("12345", "삼성TV", 150000, 3, 30, "LCD"));
		pm.add(new TV("45687", "싸피TV", 189000, 5, 55, "OLED"));
		pm.add(new TV("66374", "LG TV", 390000, 1, 27, "LCD"));
		pm.add(new Refrigerator("66374", "삼성냉장고", 398000, 1, 300));
		pm.add(new Refrigerator("28379", "싸피냉장고", 475900, 2, 400));
		
		
		for (Product v : pm.total()) 
			System.out.println(v.toString());
		
		System.out.println("---------------- find by Model Num ----------------");
		for (Product v : pm.searchByNum("12345")) 
			System.out.println(v.toString());
		
		System.out.println("---------------- find by Name ----------------");
		for (Product v : pm.searchByName("삼성")) 
			System.out.println(v.toString());
		
		System.out.println("---------------- find by TV ----------------");
		for (Product v : pm.searchByTV()) 
			System.out.println(v.toString());
		
		System.out.println("---------------- find by Refrigerator ----------------");
		for (Product v : pm.searchByRefrigerator()) 
			System.out.println(v.toString());
		
		System.out.println("---------------- del by price ----------------");
		pm.del("66374");
		for (Product v : pm.total()) 
			System.out.println(v.toString());
		
		System.out.println("---------------- sum ----------------");
		System.out.println(pm.sum());

	}

}
