package com.ssafy2;

import java.util.Arrays;

public class ProductMgr implements IProductMgr {
	private Product[] products = new Product[10];
	private int index;

	@Override
	public void add(Product product) {
		products[index++] = product;
	}

	@Override
	public Product[] total() {
		return Arrays.copyOf(products, index);
	}

	@Override
	public Product[] searchByNum(String model) {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getModel().contains(model))
				cnt++;
		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getModel().contains(model))
				tmp[cnt++] = products[i];
		return tmp;
	}

	@Override
	public Product[] searchByName(String name) {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getName().contains(name))
				cnt++;
		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getName().contains(name))
				tmp[cnt++] = products[i];
		return tmp;
	}

	@Override
	public Product[] searchByTV() {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("TV"))
				cnt++;
		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("TV"))
				tmp[cnt++] = products[i];
		return tmp;
	}

	@Override
	public Product[] searchByRefrigerator() {
		Product[] tmp;
		int cnt = 0;
		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("Refrigerator"))
				cnt++;
		tmp = new Product[cnt];
		cnt = 0;

		for (int i = 0; i < index; i++)
			if (products[i].getClass().getSimpleName().equals("Refrigerator"))
				tmp[cnt++] = products[i];
		return tmp;
	}

	@Override
	public void del(String model) {
		for (int i = 0; i < index; i++)
			if (products[i].getModel().contains(model)) {
				products[i] = products[--index];
				products[index] = null;
				i--;
			}
	}

	@Override
	public int sum() {
		int sum = 0;
		for (int i = 0; i < index; i++)
			sum += products[i].getPrice();
		return sum;
	}
}
