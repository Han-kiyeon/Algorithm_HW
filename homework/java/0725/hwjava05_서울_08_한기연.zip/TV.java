package com.ssafy2;

public class TV extends Product {
	private int inch;
	private String display;

	public TV(String model, String name, int price, int count, int inch, String display) {
		super(model, name, price, count);
		this.inch = inch;
		this.display = display;
	}

	@Override
	public String toString() {
		return super.toString() + "\t|" + inch + "inch\t|" + display;
	}

}
