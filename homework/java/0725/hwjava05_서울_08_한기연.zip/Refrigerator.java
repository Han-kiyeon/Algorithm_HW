package com.ssafy2;

public class Refrigerator extends Product {
	private int amount;

	public Refrigerator(String model, String name, int price, int count, int amount) {
		super(model, name, price, count);
		this.amount = amount;
	}

	@Override
	public String toString() {
		return super.toString() + "\t|" + amount +  "l";

	}
}
