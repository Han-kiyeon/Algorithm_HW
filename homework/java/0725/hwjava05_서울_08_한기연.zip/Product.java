package com.ssafy2;

public class Product {
	private String model; // 제품번호
	private String name;
	private int price;
	private int count;

	public Product(String model, String name, int price, int count) {
		this.model = model;
		this.name = name;
		this.price = price;
		this.count = count;
	}

	public String getModel() {
		return model;
	}

	public String getName() {
		return name;
	}

	public int getPrice() {
		return price;
	}

	public String toString() {
		return model + "\t|" + name + "  \t|" + price + "\t|" + count;
	}
}
