package com.ssafy2;

public interface IProductMgr {
	//1 . product save
	void add(Product product);
	//2. search total 
	Product[] total();
	//3. search model num 
	Product[] searchByNum(String model);
	//4. search model name 
	Product[] searchByName(String name);
	//5. search TV
	Product[] searchByTV();
	//6. search refrigerator
	Product[] searchByRefrigerator();
	// 7. del by model num 
	void del(String model);
	// 8. sum 
	int sum();
}
