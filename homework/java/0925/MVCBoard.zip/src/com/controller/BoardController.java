package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.BoardDAO;
import com.dao.IBoard;
import com.vo.Board;

//Front Controller에게 넘어온 요청을 받아 처리(Model에게 넘겨서 처리)
//Model이 작업한 결과를 받아서 request에 저장시키고 value(jsp)로 넘어감(forward)
public class BoardController {
	IBoard dao; // 인터페이스 안에 있는 메소드만 호출 가능

	public BoardController() {
		dao = new BoardDAO();
	}

	// 목록화면
	public void list(HttpServletRequest req, HttpServletResponse res) {
		ArrayList<Board> list = dao.selectAll();// Board 테이블 안의 모든 데이터 검색
		req.setAttribute("list", list);// jsp 에서 꺼내 쓰도록 list 저장

		// jsp로 forward 해서 넘기기(View로 넘어감)
		RequestDispatcher dis = req.getRequestDispatcher("/view/list.jsp");
		try {
			dis.forward(req, res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 글한개
	public void read(HttpServletRequest req, HttpServletResponse res) {
		String num = req.getParameter("num");
		Board board = dao.selectOne(num);

		req.setAttribute("b", board);// jsp 에서 꺼내 쓰도록 list 저장
		System.out.println(board);

		// jsp로 forward 해서 넘기기(View로 넘어감)
		RequestDispatcher dis = req.getRequestDispatcher("/view/read.jsp");
		try {
			dis.forward(req, res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 새 글 등록 화면 요청
	public void insertForm(HttpServletRequest req, HttpServletResponse res) {
		RequestDispatcher dis = req.getRequestDispatcher("/view/insertForm.jsp");
		try {
			dis.forward(req, res);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 새글등록 처리 요청
	public void insertProcess(HttpServletRequest req, HttpServletResponse res) {
		String title = req.getParameter("title");// 제목
		String name = req.getParameter("name");// 이름
		String pass = req.getParameter("pass");// 비밀번호
		String content = req.getParameter("content");// 내용


		Board board = new Board(null, pass, name, null , title, content, 0);

		dao.insert(board);
		
	
		req.setAttribute("b", board);

		RequestDispatcher dis = req
				.getRequestDispatcher("/view/insertSuccess.jsp");
		try {
			dis.forward(req, res);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void search(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub

	}

	// 글삭제
	public void delete(HttpServletRequest req, HttpServletResponse res) {
		String number = req.getParameter("num");
		dao.delete(number);

		// 초기화면으로 가기
		try {
			res.sendRedirect("list.bod");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void login(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub

	}

	public void loginProcess(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub

	}

	public void logout(HttpServletRequest req, HttpServletResponse res) {
		// TODO Auto-generated method stub

	}

	public void preview(HttpServletRequest req, HttpServletResponse res) {
		/** 방법 1. */
//		String num = req.getParameter("num");
//		System.out.println(num);
//		String nextPage="Error.jsp";
//		Board b;
//		try {
//			b = dao.selectOne(num);
//			req.setAttribute("result", b.getContent());
//			nextPage="/view/DescResult.jsp";
//		} catch (Exception e) {
//			e.printStackTrace();
//			req.setAttribute("msg","오류 발생,  다시 시도해 주세요.");
//		}
//		try {
//			req.getRequestDispatcher(nextPage).forward(req, res);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		/** 방법2. */
//		String num = req.getParameter("num");
//		Board b = dao.selectOne(num);
//		
//		PrintWriter out = null;
//		try {
//			out = res.getWriter();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		out.print(b.getContent());
	}

//
//	public void delete(HttpServletRequest req, HttpServletResponse res) {
//		String number = req.getParameter("num");
//		dao.delete(number);
//
//		// 초기화면으로 가기
//		try {
//			res.sendRedirect("list.cus");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//
//	public void login(HttpServletRequest req, HttpServletResponse res) {
//		RequestDispatcher dis = req.getRequestDispatcher("/view/login.jsp");
//		try {
//			dis.forward(req, res);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//	public void loginProcess(HttpServletRequest req, HttpServletResponse res) {
//		// 사용자가 입력한 ID, PW 값을 받아 체크~
//		String id = req.getParameter("id");
//		HttpSession session = req.getSession();
//		session.setAttribute("login", id); // 세션에 아이디를 저장
//
//		// 초기화면으로 가기
//		try {
//			res.sendRedirect("list.cus");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//
//	public void logout(HttpServletRequest req, HttpServletResponse res) {
//		HttpSession session = req.getSession();
//		session.setAttribute("login", null); // 세션에 세션에 저장했던 데이터만 초기화
//
//		// 초기화면으로 가기
//		try {
//			res.sendRedirect("list.cus");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}

}
