package com.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.BoardController;

// 클라이언트의 모든 요청이 들어오는 front controller
@WebFilter(filterName = "/BoardFilter", urlPatterns = {"*.bod"})
public class BoardFilter implements Filter {

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		
		req.setCharacterEncoding("UTF-8"); // 클라이언트로부터 들어오는 한글이 안깨지도록 처리
		
		BoardController bc = new BoardController();
		
		// 클라이언트로부터 들어오는 요청을 구분해서 Controller에게 작업 지시
		// ex) http://localhost:port/customer/list.cus
		// url 값에서 맨끝부분의 문자를 알아냄: /list.cus, read.cus, ...
		String reqString = req.getServletPath(); // 클라이언트가 입력한 url에서 마지막 /를 포함한 부분 무엇인지 알아내는 부분!
												 // ex) http:///localhost:8080/customer/list.cus 에서 /list.cus
		System.out.println(reqString);
		
		if(reqString.equals("/list.bod")) { //초기화면(목록화면)요청
			bc.list(req, res);
		} else if(reqString.equals("/read.bod")) { //읽기화면(글 한개) 요청
			bc.read(req, res);
		} else if(reqString.equals("/insertForm.bod")) { //새글 등록화면
			bc.insertForm(req, res);
		} else if(reqString.equals("/insertProcess.bod")) { //새글 등록 처리 요청
			bc.insertProcess(req, res);
		} else if(reqString.equals("/delete.bod")) {  //글 삭제요청
			bc.delete(req, res);
		} else if(reqString.equals("/search.bod")) { 
			bc.search(req, res);
		} else if(reqString.equals("/login.bod")) { 
			bc.login(req, res);
		} else if(reqString.equals("/loginProcess.bod")) { 
			bc.loginProcess(req, res);
		} else if(reqString.equals("/logout.bod")) { 
			bc.logout(req, res);
		}else if(reqString.equals("/preview.bod")) { 
			bc.preview(req, res);
		}
		
		// chain.doFilter(request, response); 사후처리 필요없을 때 없어도 됨!
		
	}

	public void init(FilterConfig fConfig) throws ServletException {
	}

}
