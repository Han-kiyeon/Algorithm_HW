package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.vo.Board;

//3. DAO 작성: DB에 접근해서  CRUD 작업을 수행하는 객체
public class BoardDAO implements IBoard {
	String driver = "com.mysql.cj.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/scott?"
			+ "serverTimezone=UTC&useUnicode=yes&characterEncoding=UTF-8";
	String user = "scott";
	String password = "tiger";

	// client에 의해 호출됨
	public BoardDAO() {
		try {
			// 1. Driver 등록: 앞으로 사용할 DB Driver 등록
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public Connection getConnection() {
		Connection con = null;
		try {
			// 2. Connection 생성(network)
			con = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

	@Override
	public ArrayList<Board> selectAll() {
		String query = "select num, name, title, wdate, count from Board order by num desc";
		ArrayList<Board> list = new ArrayList<>();
		Connection con = null;
		Statement stat = null;
		ResultSet rs = null;

		try {
			con = getConnection();
			stat = con.createStatement();
			rs = stat.executeQuery(query); // select
			while (rs.next()) {
				String num = rs.getString(1);
				String name = rs.getString(2);
				String title = rs.getString(3);
				String wdate = rs.getString(4);
				int count = Integer.parseInt(rs.getString(5));
				Board c = new Board(num, null, name, wdate, title, null, count); // vo로
																										// 포장
				list.add(c);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		close(rs, stat, null, con);
		return list;
	}

//	@Override
//	public int insert(Board c) {
//		String query = "insert into Board values(?,?,?)";
//		Connection con = null;
//		PreparedStatement pstat = null;
//		int rs = -1;
//		try {
//			con = getConnection();// 2
//			pstat = con.prepareStatement(query);// 3
//			pstat.setString(1, c.getNum());
//			pstat.setString(2, c.getName());
//			pstat.setString(3, c.getAddress());
//			rs = pstat.executeUpdate();// 4
//
//			close(null, null, pstat, con);
//			return rs;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		close(null, null, pstat, con);
//		return rs;
//	}
//
//	@Override
//	public int delete(String num) {
//		String query = "delete from Board where num = " + num;
//		Connection con = null;
//		Statement stat = null;
//		int rs = -1;
//		try {
//			con = getConnection();// 2
//			stat = con.createStatement();// 3
//			rs = stat.executeUpdate(query);// 4
//
//			close(null, stat, null, con);
//			return rs;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		close(null, stat, null, con);
//		return rs;
//	}
//
//	@Override
//	public int update(String num, String address) {
//		String query = "update Board set address = '" + address + "' where num = " + num;
//		Connection con = null;
//		Statement stat = null;
//		int rs = -1;
//		try {
//			con = getConnection();// 2
//			stat = con.createStatement();// 3
//			rs = stat.executeUpdate(query);// 4
//
//			close(null, stat, null, con);
//			return rs;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		close(null, stat, null, con);
//		return rs;
//	}
//
//	@Override
//	public ArrayList<Board> findByAddress(String address) {
//		String query = "select * from Board where address = '" + address + "' order by num";
//		ArrayList<Board> c = new ArrayList<>();
//		Connection con = null;
//		Statement stat = null;
//		ResultSet rs = null;
//		try {
//			con = getConnection();// 2
//			stat = con.createStatement();// 3
//			rs = stat.executeQuery(query);// 4
//
//			while (rs.next()) {// 5
//				String num = rs.getString(1);
//				String name = rs.getString(2);
//				String ad = rs.getString(3);
//
//				//c.add(new Board(num, name, ad));
//			}
//			close(rs, stat, null, con);
//			return c;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		close(rs, stat, null, con);
//		return c;
//	}
//
	public void close(ResultSet rs, Statement stat, PreparedStatement pstat,
			Connection con) {
		try {
			if (rs != null)
				rs.close();
			if (stat != null)
				stat.close();
			if (pstat != null)
				pstat.close();
			if (con != null)
				con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Board selectOne(String num) {
		String query = "select num, name, wdate, count, title, content from Board where num = "
				+ num;
		Board result = new Board();
		Connection con = null;
		Statement stat = null;
		ResultSet rs = null;

		try {
			con = getConnection();
			stat = con.createStatement();
			rs = stat.executeQuery(query); // select

			rs.next();
			result.setNum(rs.getString(1));
			result.setName(rs.getString(2));
			result.setWdate(rs.getString(3));
			result.setCount(Integer.parseInt(rs.getString(4)));
			result.setTitle(rs.getString(5));
			result.setContent(rs.getString(6));

		} catch (Exception e) {
			e.printStackTrace();
		}
		close(rs, stat, null, con);
		return result;
	}

	@Override
   public void insert(Board b) {
       String query = "insert into board (pass, name, wdate, title, content, count) values(?, ?, SYSDATE(), ?, ?, 0)";
       Connection con = null;
       PreparedStatement pstat = null;
       try {
           con = getConnection();
           pstat = con.prepareStatement(query);
           pstat.setString(1, b.getPass());
           pstat.setString(2, b.getName());
           pstat.setString(3, b.getTitle());
           pstat.setString(4, b.getContent());
           pstat.executeUpdate();
       } catch (Exception e) {
           e.printStackTrace();
       }
       close(null, null, pstat, con);
   }

	@Override
	public void delete(String num) {
		// TODO Auto-generated method stub

	}

	@Override
	public ArrayList<Board> search(String condition, String word) {
		// TODO Auto-generated method stub
		return null;
	}

}