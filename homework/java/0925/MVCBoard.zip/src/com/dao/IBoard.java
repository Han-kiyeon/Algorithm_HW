package com.dao;

import java.util.ArrayList;

import com.vo.Board;

public interface IBoard {
	public ArrayList<Board> selectAll(); //목록화면에서 모든 글 검색
	public Board selectOne(String num); //글읽기화면에서 해당 글 검색
	public void insert(Board b); //새글등록
	public void delete(String num); //글 삭제
	public ArrayList<Board> search(String condition, String word); //검색 (검색조건:이름, 제목|검색내용)
	
}
